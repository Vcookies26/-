﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        TextWriter save_out = Console.Out;
        TextReader save_in = Console.In;
        var new_out = new StreamWriter(@"output.txt");
        var new_in = new StreamReader(@"input.txt");
        Console.SetOut(new_out);
        Console.SetIn(new_in);

        double r, L, S;
        r = Convert.ToDouble(Console.ReadLine());

        if ((r <= 0) || (r >= 100000))
            Console.WriteLine("ERROR");
        else
        {
            L = 2 * 3.14 * r;
            S = 3.14 * r * r;
            Console.WriteLine(String.Format("{0:0.000}", L));
            Console.WriteLine(String.Format("{0:0.000}", S));
        }

        Console.SetOut(save_out); new_out.Close();
        Console.SetIn(save_in); new_in.Close();
    }
}