﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace OopMonitoringLab
{
    // ==========================
    // 1. МОДЕЛЬ ЗАПРОСА И ОТВЕТА
    // ==========================

    public class Request
    {
        public string ServiceName { get; set; } = string.Empty;
        public int PayloadSize { get; set; }
        public int? DeadlineMs { get; set; }
        public Guid RequestId { get; } = Guid.NewGuid();

        public Request(string serviceName, int payloadSize, int? deadlineMs = null)
        {
            ServiceName = serviceName;
            PayloadSize = payloadSize;
            DeadlineMs = deadlineMs;
        }
    }

    public class Response
    {
        public bool IsSuccess { get; set; }
        public int LatencyMs { get; set; }
        public string? ErrorCode { get; set; }
        public string? ErrorMessage { get; set; }
        public int RetryCount { get; set; } = 0;

        public Response(bool isSuccess, int latencyMs, string? errorCode = null,
            string? errorMessage = null)
        {
            IsSuccess = isSuccess;
            LatencyMs = latencyMs;
            ErrorCode = errorCode;
            ErrorMessage = errorMessage;
        }
    }

    // ================================
    // 2. ИНТЕРФЕЙС СЕРВИСА
    // ================================

    public interface IService
    {
        string Name { get; }
        int BaseLatencyMs { get; }
        double FailureProbability { get; }
        IRetryPolicy? RetryPolicy { get; set; }

        Response Process(Request request);
    }

    // ================================
    // 3. ИНТЕРФЕЙС ПОЛИТИКИ ПОВТОРОВ
    // ================================

    public interface IRetryPolicy
    {
        int MaxRetries { get; }
        bool ShouldRetry(Response response);
        int GetDelayMs(int retryCount);
    }

    // ================================
    // 4. ПОЛИТИКА ЭКСПОНЕНЦИАЛЬНОГО BACKOFF
    // ================================

    public class ExponentialBackoffRetryPolicy : IRetryPolicy
    {
        public int MaxRetries { get; }
        public int InitialDelayMs { get; }
        public double Multiplier { get; }

        public ExponentialBackoffRetryPolicy(int maxRetries, int initialDelayMs, double multiplier)
        {
            MaxRetries = maxRetries;
            InitialDelayMs = initialDelayMs;
            Multiplier = multiplier;
        }

        public bool ShouldRetry(Response response)
        {
            return !response.IsSuccess && response.RetryCount < MaxRetries;
        }

        public int GetDelayMs(int retryCount)
        {
            if (retryCount <= 0) return InitialDelayMs;
            return (int)(InitialDelayMs * Math.Pow(Multiplier, retryCount - 1));
        }
    }

    // ================================
    // 5. БАЗОВЫЙ КЛАСС СЕРВИСА
    // ================================

    public abstract class ServiceBase : IService
    {
        private static readonly Random _random = new Random();
        protected static readonly object _lockObject = new object();

        public string Name { get; protected set; }
        public int BaseLatencyMs { get; protected set; }
        public double FailureProbability { get; protected set; }
        public IRetryPolicy? RetryPolicy { get; set; }

        protected ServiceBase(string name, int baseLatencyMs, double failureProbability)
        {
            Name = name;
            BaseLatencyMs = baseLatencyMs;
            FailureProbability = failureProbability;
        }

        public virtual Response Process(Request request)
        {
            int retryCount = 0;
            int totalLatency = 0;
            Response? finalResponse = null;

            do
            {
                if (retryCount > 0 && RetryPolicy != null)
                {
                    int delay = RetryPolicy.GetDelayMs(retryCount);
                    // В реальной системе здесь было бы await Task.Delay(delay)
                    Thread.Sleep(delay); // Для демонстрации в консольном приложении
                    totalLatency += delay;
                }

                // Генерация случайной задержки вокруг базовой
                int latency;
                lock (_lockObject)
                {
                    // Добавляем случайное отклонение ±50% от базовой задержки
                    int deviation = BaseLatencyMs / 2;
                    latency = BaseLatencyMs + _random.Next(-deviation, deviation);
                    latency = Math.Max(10, latency); // Минимум 10мс
                }

                // Проверка на ошибку
                bool isSuccess;
                lock (_lockObject)
                {
                    isSuccess = _random.NextDouble() > FailureProbability;
                }

                var response = new Response(isSuccess, latency + totalLatency)
                {
                    RetryCount = retryCount
                };

                if (!isSuccess)
                {
                    response.ErrorCode = "SERVICE_ERROR";
                    response.ErrorMessage = $"Ошибка обработки в сервисе {Name}";
                }

                Log(request, response, retryCount);

                if (isSuccess)
                {
                    finalResponse = response;
                    break;
                }

                retryCount++;
                totalLatency += latency;

            } while (RetryPolicy != null && RetryPolicy.ShouldRetry(new Response(false, 0) { RetryCount = retryCount }));

            finalResponse ??= new Response(false, totalLatency)
            {
                ErrorCode = "MAX_RETRIES_EXCEEDED",
                ErrorMessage = $"Превышено максимальное количество попыток ({retryCount})",
                RetryCount = retryCount
            };

            return finalResponse;
        }

        protected virtual void Log(Request request, Response response, int retryCount)
        {
            string status = response.IsSuccess ? "УСПЕХ" : "ОШИБКА";
            string retryInfo = retryCount > 0 ? $", попытка #{retryCount + 1}" : "";
            Console.WriteLine($"[{DateTime.Now:HH:mm:ss.fff}] Сервис '{Name}': {status}" +
                $", задержка={response.LatencyMs}мс{retryInfo}");
        }
    }

    // ================================
    // 6. КОНКРЕТНЫЕ СЕРВИСЫ
    // ================================

    public class FastService : ServiceBase
    {
        public FastService()
            : base("FastService", baseLatencyMs: 50, failureProbability: 0.10)
        {
        }
    }

    public class SlowService : ServiceBase
    {
        public SlowService()
            : base("SlowService", baseLatencyMs: 200, failureProbability: 0.20)
        {
        }
    }

    // ================================
    // 7. МЕТРИКИ И СБОР НАБЛЮДАЕМОСТИ
    // ================================

    public class ServiceMetrics
    {
        public string ServiceName { get; }
        public int TotalRequests { get; private set; }
        public int SuccessfulRequests { get; private set; }
        public int FailedRequests { get; private set; }
        public int RetryAttempts { get; private set; }
        public int SavedByRetries { get; private set; }
        public double AverageLatencyMs { get; private set; }
        public int MaxLatencyMs { get; private set; }
        public int TotalLatencyMs { get; private set; }

        // Храним базовую задержку сервиса для анализа
        private int _serviceBaseLatencyMs;

        public ServiceMetrics(string serviceName, int baseLatencyMs = 0)
        {
            ServiceName = serviceName;
            _serviceBaseLatencyMs = baseLatencyMs;
        }

        public double ErrorRate => TotalRequests > 0 ? (double)FailedRequests / TotalRequests : 0;
        public double RetryRate => TotalRequests > 0 ? (double)RetryAttempts / TotalRequests : 0;
        public double SavedByRetriesRate => FailedRequests > 0 ? (double)SavedByRetries / FailedRequests : 0;

        public void Update(Response response)
        {
            TotalRequests++;
            TotalLatencyMs += response.LatencyMs;

            if (response.IsSuccess)
            {
                SuccessfulRequests++;
                if (response.RetryCount > 0)
                {
                    SavedByRetries++;
                }
            }
            else
            {
                FailedRequests++;
            }

            RetryAttempts += response.RetryCount;
            AverageLatencyMs = (double)TotalLatencyMs / TotalRequests;

            if (response.LatencyMs > MaxLatencyMs)
            {
                MaxLatencyMs = response.LatencyMs;
            }
        }

        // Метод для получения базовой задержки сервиса
        public int GetServiceBaseLatency()
        {
            return _serviceBaseLatencyMs;
        }
    }

    public interface IMetricsCollector
    {
        void RegisterService(IService service);
        void Record(Request request, Response response);
        IReadOnlyCollection<ServiceMetrics> GetCurrentMetrics();
        ServiceMetrics GetMetricsForService(string serviceName);
    }

    public class InMemoryMetricsCollector : IMetricsCollector
    {
        private readonly Dictionary<string, ServiceMetrics> _metricsByService = new Dictionary<string, ServiceMetrics>();
        private readonly Dictionary<string, int> _serviceBaseLatencies = new Dictionary<string, int>();

        public void RegisterService(IService service)
        {
            if (!_metricsByService.ContainsKey(service.Name))
            {
                _metricsByService[service.Name] = new ServiceMetrics(service.Name, service.BaseLatencyMs);
                _serviceBaseLatencies[service.Name] = service.BaseLatencyMs;
            }
        }

        public void Record(Request request, Response response)
        {
            if (_metricsByService.TryGetValue(request.ServiceName, out var metrics))
            {
                metrics.Update(response);
            }
        }

        public IReadOnlyCollection<ServiceMetrics> GetCurrentMetrics()
        {
            return _metricsByService.Values.ToList().AsReadOnly();
        }

        public ServiceMetrics GetMetricsForService(string serviceName)
        {
            return _metricsByService[serviceName];
        }

        // Метод для получения базовой задержки сервиса
        public int GetServiceBaseLatency(string serviceName)
        {
            return _serviceBaseLatencies.TryGetValue(serviceName, out var latency) ? latency : 0;
        }
    }

    // ================================
    // 8. ОЦЕНКА "ЗДОРОВЬЯ" СЕРВИСА
    // ================================

    public enum ServiceHealth
    {
        Healthy,
        Degraded,
        Unhealthy
    }

    public class ServiceHealthEvaluator
    {
        public double MaxHealthyErrorRate { get; set; } = 0.05;
        public double MaxDegradedErrorRate { get; set; } = 0.20;
        public int MaxHealthyLatencyMs { get; set; } = 150;
        public int MaxDegradedLatencyMs { get; set; } = 400;

        public ServiceHealth Evaluate(ServiceMetrics metrics)
        {
            if (metrics.TotalRequests == 0)
                return ServiceHealth.Healthy;

            double errorRate = metrics.ErrorRate;
            double avgLatency = metrics.AverageLatencyMs;

            if (errorRate <= MaxHealthyErrorRate && avgLatency <= MaxHealthyLatencyMs)
                return ServiceHealth.Healthy;

            if (errorRate > MaxDegradedErrorRate || avgLatency > MaxDegradedLatencyMs)
                return ServiceHealth.Unhealthy;

            return ServiceHealth.Degraded;
        }

        public string GetHealthStatus(ServiceHealth health)
        {
            return health switch
            {
                ServiceHealth.Healthy => "✓ Healthy",
                ServiceHealth.Degraded => "⚠ Degraded",
                ServiceHealth.Unhealthy => "✗ Unhealthy",
                _ => "Unknown"
            };
        }
    }

    // ================================
    // 9. ГЛАВНЫЙ МОДУЛЬ (Main)
    // ================================

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("=== Лабораторная работа 2-3: Моделирование системы обработки запросов ===");
            Console.WriteLine("=== Вариант 2: Экспоненциальный backoff ===\n");

            // Создание сервисов с политикой повторов
            var fastService = new FastService();
            var slowService = new SlowService();

            // Настройка политики экспоненциального backoff
            var retryPolicy = new ExponentialBackoffRetryPolicy(
                maxRetries: 3,
                initialDelayMs: 100,
                multiplier: 2.0
            );

            fastService.RetryPolicy = retryPolicy;
            slowService.RetryPolicy = retryPolicy;

            // Создание сборщика метрик
            IMetricsCollector metricsCollector = new InMemoryMetricsCollector();
            metricsCollector.RegisterService(fastService);
            metricsCollector.RegisterService(slowService);

            ServiceHealthEvaluator healthEvaluator = new ServiceHealthEvaluator();

            // Генерация запросов
            var random = new Random();
            List<Request> requests = new List<Request>();

            for (int i = 0; i < 50; i++)
            {
                string serviceName = random.NextDouble() > 0.5 ? "FastService" : "SlowService";
                int payloadSize = random.Next(50, 500);
                int? deadline = random.NextDouble() > 0.7 ? random.Next(100, 500) : null;

                requests.Add(new Request(serviceName, payloadSize, deadline));
            }

            Console.WriteLine($"Сгенерировано {requests.Count} запросов\n");
            Console.WriteLine("Параметры политики повторов:");
            Console.WriteLine($"- Максимальное число повторов: {retryPolicy.MaxRetries}");
            Console.WriteLine($"- Начальная задержка: {retryPolicy.InitialDelayMs} мс");
            Console.WriteLine($"- Коэффициент роста: {retryPolicy.Multiplier}");
            Console.WriteLine();

            // Обработка запросов
            int processedCount = 0;
            foreach (var request in requests)
            {
                processedCount++;
                IService service = request.ServiceName == fastService.Name ? fastService : slowService;

                Response response = service.Process(request);
                metricsCollector.Record(request, response);

                // Вывод состояния каждые 10 запросов
                if (processedCount % 10 == 0)
                {
                    PrintCurrentStatus(metricsCollector, healthEvaluator, processedCount);
                }
            }

            // Финальный отчет
            PrintFinalReport(metricsCollector, healthEvaluator);
            PrintRetryAnalysisReport(metricsCollector, fastService, slowService);
        }

        private static void PrintCurrentStatus(IMetricsCollector collector, ServiceHealthEvaluator evaluator, int processedCount)
        {
            Console.WriteLine($"\n=== Статус после {processedCount} запросов ===");
            Console.WriteLine(new string('-', 80));

            var metrics = collector.GetCurrentMetrics();
            foreach (var m in metrics)
            {
                var health = evaluator.Evaluate(m);
                var healthStatus = evaluator.GetHealthStatus(health);

                Console.WriteLine($"Сервис: {m.ServiceName} [{healthStatus}]");
                Console.WriteLine($"  Запросы: {m.TotalRequests} (Успешно: {m.SuccessfulRequests}, Ошибки: {m.FailedRequests})");
                Console.WriteLine($"  Задержка: средняя={m.AverageLatencyMs:F1}мс, макс={m.MaxLatencyMs}мс");
                Console.WriteLine($"  Ошибки: {m.ErrorRate:P1}, Повторы: {m.RetryRate:F2}/запрос");
                Console.WriteLine($"  Спасено повторами: {m.SavedByRetries} ({m.SavedByRetriesRate:P1})");
                Console.WriteLine();
            }
        }

        private static void PrintFinalReport(IMetricsCollector collector, ServiceHealthEvaluator evaluator)
        {
            Console.WriteLine("\n" + new string('=', 80));
            Console.WriteLine("ФИНАЛЬНЫЙ ОТЧЕТ");
            Console.WriteLine(new string('=', 80));

            var metrics = collector.GetCurrentMetrics();
            Console.WriteLine("\nОБЩАЯ СТАТИСТИКА:");

            int totalRequests = metrics.Sum(m => m.TotalRequests);
            int totalSuccessful = metrics.Sum(m => m.SuccessfulRequests);
            int totalFailed = metrics.Sum(m => m.FailedRequests);
            int totalRetries = metrics.Sum(m => m.RetryAttempts);
            int totalSaved = metrics.Sum(m => m.SavedByRetries);

            double overallErrorRate = totalRequests > 0 ? (double)totalFailed / totalRequests : 0;
            double avgRetriesPerRequest = totalRequests > 0 ? (double)totalRetries / totalRequests : 0;
            double saveEffectiveness = totalFailed > 0 ? (double)totalSaved / totalFailed : 0;

            Console.WriteLine($"Всего запросов: {totalRequests}");
            Console.WriteLine($"Успешных: {totalSuccessful} ({totalSuccessful / (double)totalRequests:P1})");
            Console.WriteLine($"Ошибочных: {totalFailed} ({overallErrorRate:P1})");
            Console.WriteLine($"Всего попыток повторов: {totalRetries}");
            Console.WriteLine($"Среднее число повторов на запрос: {avgRetriesPerRequest:F2}");
            Console.WriteLine($"Запросов спасено повторами: {totalSaved} ({saveEffectiveness:P1} от всех ошибок)");

            Console.WriteLine("\nДЕТАЛЬНАЯ СТАТИСТИКА ПО СЕРВИСАМ:");
            Console.WriteLine(new string('-', 80));

            foreach (var m in metrics)
            {
                var health = evaluator.Evaluate(m);
                var healthStatus = evaluator.GetHealthStatus(health);

                Console.WriteLine($"\n{m.ServiceName} [{healthStatus}]");
                Console.WriteLine(new string('-', 40));
                Console.WriteLine($"Запросы: {m.TotalRequests}");
                Console.WriteLine($"Успешных: {m.SuccessfulRequests} ({m.SuccessfulRequests / (double)m.TotalRequests:P1})");
                Console.WriteLine($"Ошибочных: {m.FailedRequests} ({m.ErrorRate:P1})");
                Console.WriteLine($"Попыток повторов: {m.RetryAttempts} ({m.RetryRate:F2}/запрос)");
                Console.WriteLine($"Спасено повторами: {m.SavedByRetries} ({m.SavedByRetriesRate:P1} от ошибок)");
                Console.WriteLine($"Средняя задержка: {m.AverageLatencyMs:F1} мс");
                Console.WriteLine($"Максимальная задержка: {m.MaxLatencyMs} мс");
                Console.WriteLine($"Общая задержка: {m.TotalLatencyMs} мс");
            }
        }

        private static void PrintRetryAnalysisReport(IMetricsCollector collector, FastService fastService, SlowService slowService)
        {
            

            var metrics = collector.GetCurrentMetrics();

            foreach (var m in metrics)
            {
                // Получаем базовую задержку сервиса
                int baseLatencyMs = m.ServiceName switch
                {
                    "FastService" => fastService.BaseLatencyMs,
                    "SlowService" => slowService.BaseLatencyMs,
                    _ => 0
                };

                // Расчет теоретических показателей без повторов
                int theoreticalErrors = (int)(m.TotalRequests * (1 - m.SavedByRetriesRate));
                int theoreticalSuccess = m.TotalRequests - theoreticalErrors;
                double theoreticalErrorRate = (double)theoreticalErrors / m.TotalRequests;

                // Расчет влияния на задержку
                double estimatedAdditionalLatency = 0;
                if (m.RetryAttempts > 0)
                {
                    // Оценка: каждый повтор добавляет время ожидания + время обработки
                    // Упрощенная модель: считаем, что каждый повтор в среднем добавляет baseLatency
                    estimatedAdditionalLatency = (m.AverageLatencyMs - baseLatencyMs) / m.RetryRate;
                }
            }

        }
    }
}