﻿using System;

namespace LR_One
{
    class Program
    {
        static void Main(string[] args)
        {
            // Задание 1: Вывод персональной информации
            Console.WriteLine("ЛАБОРАТОРНАЯ РАБОТА 1. РАЗРАБОТКА КОНСОЛЬНОГО ПРИЛОЖЕНИЯ");
            Console.WriteLine("Варакса Марина Алексеевна");
            Console.WriteLine("ИДБ-23-01, 09.03.01");
            Console.WriteLine("26.08.2004");
            Console.WriteLine("Населенный пункт постоянного места жительства: Москва");
            Console.WriteLine("Любимый предмет в школе: Информатика");
            Console.WriteLine("Увлечения: конный спорт\n");

            // Задание 2: Вычисления по формуле Se = w111 + bt - x + y * w
            int w, t, b, x, y, Se = 0;
            Console.WriteLine("=== Ввод данных для вычисления выражения ===");

            Console.Write("Введите значение переменной w: ");
            w = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите значение переменной t: ");
            t = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите значение переменной b: ");
            b = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите значение переменной x: ");
            x = Convert.ToInt32(Console.ReadLine());

            Console.Write("Введите значение переменной y: ");
            y = Convert.ToInt32(Console.ReadLine());

            // Вычисление выражения
            Se = w * 111 + b * t - x + y * w;

            // Вывод результатов с использованием форматной строки
            Console.WriteLine("\n=== Результаты вычислений ===");
            Console.WriteLine("Исходные значения переменных:");
            Console.WriteLine("w = {0}, t = {1}, b = {2}, x = {3}, y = {4}", w, t, b, x, y);
            Console.WriteLine("Вычисление выражения: Se = w * 111 + b * t - x + y * w");
            Console.WriteLine("Se = {0} * 111 + {1} * {2} - {3} + {4} * {5}", w, b, t, x, y, w);
            Console.WriteLine("Промежуточные вычисления:");
            Console.WriteLine("w * 111 = {0} * 111 = {1}", w, w * 111);
            Console.WriteLine("b * t = {0} * {1} = {2}", b, t, b * t);
            Console.WriteLine("y * w = {0} * {1} = {2}", y, w, y * w);
            Console.WriteLine("Итоговый результат: Se = {0}", Se);

            Console.ReadKey();
        }
    }
}