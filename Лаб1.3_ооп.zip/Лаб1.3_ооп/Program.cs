﻿using System;
using System.IO;

class Program
{
    static void Main(string[] args)
    {
        TextWriter save_out = Console.Out;
        TextReader save_in = Console.In;
        var new_out = new StreamWriter(@"output.txt");
        var new_in = new StreamReader(@"input.txt");
        Console.SetOut(new_out);
        Console.SetIn(new_in);

        int t = 0, N = 1;
        double X = 0, Y = 0, Z = 0;

        t = Convert.ToInt32(Console.ReadLine());
        N = Convert.ToInt32(Console.ReadLine());
        X = Convert.ToDouble(Console.ReadLine());
        Y = Convert.ToDouble(Console.ReadLine());

        if (t == 0) // Цикл for
        {
            for (int i = 1; i <= N; i++)
            {
                double denominator = i * (i + 2) * (i + 4);
                double term;

                if (i % 2 == 1) // Нечетные члены - положительные с Y в степени (i-1)
                {
                    int power = i - 1;
                    term = Math.Pow(Y, power) / denominator;
                    Z += term;
                }
                else // Четные члены - отрицательные с X в степени (i-1)
                {
                    int power = i - 1;
                    term = Math.Pow(X, power) / denominator;
                    Z -= term;
                }
            }
        }
        else if (t == 1) // Цикл while
        {
            int i = 1;
            while (i <= N)
            {
                double denominator = i * (i + 2) * (i + 4);
                double term;

                if (i % 2 == 1)
                {
                    int power = i - 1;
                    term = Math.Pow(Y, power) / denominator;
                    Z += term;
                }
                else
                {
                    int power = i - 1;
                    term = Math.Pow(X, power) / denominator;
                    Z -= term;
                }
                i++;
            }
        }
        else if (t == 2) // Цикл do-while
        {
            int i = 1;
            do
            {
                double denominator = i * (i + 2) * (i + 4);
                double term;

                if (i % 2 == 1)
                {
                    int power = i - 1;
                    term = Math.Pow(Y, power) / denominator;
                    Z += term;
                }
                else
                {
                    int power = i - 1;
                    term = Math.Pow(X, power) / denominator;
                    Z -= term;
                }
                i++;
            } while (i <= N);
        }

        Console.WriteLine(String.Format("{0:0.000000}", Z));

        Console.SetOut(save_out);
        new_out.Close();
        Console.SetIn(save_in);
        new_in.Close();
    }
}